---
layout: page
title: Welcome
---

The last few years have seen rapid developments in the deployment and adoption
of ML systems. And yet, we lack a cohesive understanding of how these systems
work, and the principles and laws (if any!) that govern their behavior. To this
end, the goal of this reading group will be to explore the intersection of
cutting-edge experiments and corresponding explanations, with the goal of
answering a few questions: 

- How can tools from statistics, CS theory, and operations research inform a better understanding of machine learning algorithms and systems?
- What are the right questions to ask, and phenomena to explain—at what level of abstraction should we be aiming to explain them?
- How might we devise theoretical models that not only explain unexpected phenomena, but also predict new phenomena that we can verify experimentally?

## More info

- **Meetings:** Thursdays at 5pm (CoDa W101)
- **Mailing List:** [reform-ml-list@stanford.edu](mailto:reform-ml-list@stanford.edu)
- **Sign up to be a discussant:** [Google Form](https://forms.gle/Pdz9AQ7mWVDMBJwm7)
- **Questions?** Email anaymehrotra1 [at] gmail [dot] com, saberi [at] stanford [dot] edu, gvelegkas [at] google [dot] com
- **[Tentative schedule & Past meetings](schedule.md)**
