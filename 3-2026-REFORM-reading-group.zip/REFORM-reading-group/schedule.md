---
layout: page
title: "Schedule and Past Meetings"
permalink: /schedule/
---

Meetings are held every Thursday at 5pm ((CoDa W101)). 

A list of the topics, suggested papers, and timeline for this quarter is available [here](https://docs.google.com/spreadsheets/d/14ChmArQCa4wlQ3vE7taNzmzd96d0N_a7XaJOgaDPunU/edit?gid=0#gid=0)

Please sign up to be a discussant [here](https://tinyurl.com/reform-ml-signup-w26)!
Goal(s) of the discussant group is to:

- Do a single “deep dive” per week about one subject (this can be multiple papers) 
- We have suggested several papers for each week, more than one can cover thoroughly in a week. Pick a small, focused set of papers and read them thoroughly
- Prepare a 20-30 minute presentation, accessible to a second year PhD student, focusing on (a) seeding discussion and (b) identifying gaps and connections, and (c) formulating open problems

Signing up is a great way to (1) force yourself to engage with the content of the paper (2) get to know your co-discussant(s) and (3) ensure the success of the reading group!

# Upcoming Sessions

| Date       | Topic                          | Resources                      |
|------------|--------------------------------|--------------------------------|
| 2024-10-16 | Introduction                              | [Slides](/assets/FirstMeetingSlides.pdf)        |
| 2024-10-23 | Scaling Laws 1 (Training Compute-Optimal Language Models)  | [Paper](https://arxiv.org/abs/2203.15556) [Slides](/assets/Meeting1-ChinchillaPaper-Slides.pdf)   |
| 2024-10-30 | Scaling Laws 2 (Explaining Neural Scaling Laws)           |  [Paper](https://arxiv.org/abs/2102.06701) [Slides](/assets/TheoryScalingSlides.pdf) |
| 2024-11-06 | Data Selection 1 (Perplexity Correlations, Scaling Laws + Data Filtering)           | [Paper 1](https://arxiv.org/abs/2409.05816) [Paper 2](https://arxiv.org/abs/2404.07177) [Slides](/assets/DataSelection1.pdf) |
| 2024-11-13 | Data Selection 2 (DsDm, LESS) | [Paper 1](https://arxiv.org/abs/2401.12926) [Paper 2](https://arxiv.org/abs/2402.04333) [Tutorial](https://ml-data-tutorial.org/) [Slides (DsDm)](/assets/DataAttributionSlides.pdf) [Slides (LESS)](/assets/LESSSlides.pdf) |
| 2024-11-20 | Data Selection 3 (Statistical Theory) | [Paper](https://arxiv.org/abs/2309.14563) [Slides](/assets/DataSelection3.pdf) |
| 2024-11-20 | Data Selection 3 (Pruning, Prediction) | [Paper 1](https://arxiv.org/abs/2206.14486) [Paper 2](https://arxiv.org/abs/2210.01072) |
| 2025-01-22 | Post-training 1 (RLHF, AlpacaFarm) | [Paper 1](https://arxiv.org/abs/2203.02155) [Paper 2](https://arxiv.org/abs/2305.14387) [Slides](/assets/PostTraining-1.pdf) |
| 2025-01-29 | No meeting (ICML Deadline) |       |
| 2025-02-05 | Post-training 2 (Direct methods & Offline RL) | [Paper 1](https://arxiv.org/abs/2305.18290) [Paper 2](https://arxiv.org/abs/2410.08847) [Paper 3](https://arxiv.org/abs/2406.01462) [Paper 4](https://arxiv.org/abs/2405.08448) [Slides 1](/assets/RL-1.pdf) [Slides 2](/assets/RL-2.pdf)  |
| 2025-02-12 | Post-training 3 (DeepSeek) | [Paper](https://github.com/deepseek-ai/DeepSeek-R1/blob/main/DeepSeek_R1.pdf) [Slides](/assets/DeepSeek-Slides.pdf) |
| 2025-02-19 | Post-training 4 (Synthetic Data) | [Slides](/assets/SyntheticData.pdf) |
| 2025-02-26 | Post-training 4 (Synthetic Data & Self-Improvement) | [Paper 1](https://arxiv.org/abs/2404.01413) [Paper 2](https://arxiv.org/abs/2502.01612) [Slides](/assets/SyntheticData-2.pdf) |
| 2025-03-04 | Post-training 5 (Simplicity) | [Paper 1](https://arxiv.org/abs/2501.19393) [Paper 2](https://arxiv.org/abs/2409.14254) [Slides](/assets/InstructionFollowing.pdf) |
| 2025-03-11 | Post-training 5 (In-Context Learning) | [Slides](/assets/ICLSurvey.pdf) |
|(Between-quarter break)|||
| 2025-04-09 | Reasoning 1 (Introduction) | [Slides](/assets/REFORMFirstMeeting-Spring2025.pdf) |
| 2025-04-16 | Reasoning 2 (STaR) | [Paper](https://arxiv.org/abs/2203.14465) |
| 2025-04-23 | Reasoning 3 (Process rewards) | [Slides](/assets/ProcessRewards.pdf) [Paper 1](http://arxiv.org/abs/2211.14275) [Paper 2](https://arxiv.org/abs/2305.20050) |
| 2025-04-30 | Reasoning 4 (More Self-improvement) | [Paper](https://arxiv.org/abs/2210.11610) |
|(Summer break)|||
| 2025-10-09 | Post-deployment/Safety 1 (CoT Monitoring) | [Paper 1](https://arxiv.org/abs/2505.05410) [Paper 2](https://arxiv.org/abs/2507.05246) [Slides](/assets/REFORMFirstMeeting-Fall2025.pdf) |
| 2025-10-16 | Post-deployment/Safety 2 (Jailbreaking, Elicitation) | [Paper 1](https://arxiv.org/abs/2010.15980) [Paper 2](https://arxiv.org/abs/2307.15043) [Paper 3](https://arxiv.org/abs/2502.01236) [Slides](/assets/Prompting.pdf) |
| 2025-10-23 | Post-deployment/Safety 3 (Hallucinations) | [Paper 1](https://arxiv.org/abs/2509.04664) [Paper 2](https://arxiv.org/abs/2507.16806) [Slides 1](/assets/Hallucinations.pdf) [Slides 2](/assets/RLCR.pdf) |
| 2025-10-30 | Post-deployment/Safety 3 (Privacy and Memorization) | [Slides 1](/assets/Privacy1.pdf) [Slides 2](/assets/Privacy2.pdf) [Paper 1](https://arxiv.org/abs/1802.08232) [Paper 2](https://arxiv.org/abs/2012.07805) |
| 2025-11-06 | Post-deployment/Safety 4 (Emergent Misalignment) | [Paper](https://arxiv.org/abs/2502.17424) |
| 2025-11-13 | Post-deployment/Safety 5 (Out-of-Context Reasoning) | [Slides](/assets/OOCReasoning.pdf) [Paper 1](https://arxiv.org/abs/2309.00667) [Paper 2](https://arxiv.org/abs/2406.14546) [Paper 3](https://arxiv.org/abs/2412.04614) [Paper 4](https://arxiv.org/abs/2506.10887) |
| 2026-01-22 | Introduction + Sharpness and Training Dynamics 1 (Edge of Stability) | [Slides](https://anaymehrotra.com/REFORM-reading-group/assets/EOS.pdf) [Paper](https://arxiv.org/abs/2103.00065) [Extra Reading 1](https://arxiv.org/abs/2209.15594) [Extra Reading 2](https://arxiv.org/abs/2207.12678) |
| 2026-02-05 | Sharpness and Training Dynamics 2 (Sharpness-Aware Minimization) | [Slides 1](https://anaymehrotra.com/REFORM-reading-group/assets/05_02_2026_SAM_1.pdf) [Slides 2](https://anaymehrotra.com/REFORM-reading-group/assets/05_02_2026_SAM_2.pdf)  [Paper 1](https://arxiv.org/abs/2010.01412) [Paper 2](https://arxiv.org/abs/2302.07011) |
| 2026-02-12 | Overfitting and Generalization 1: Double Descent | [Slides 1](https://anaymehrotra.com/REFORM-reading-group/assets/12_02_2026_Double_Descent_1.pdf) [Slides 2](https://anaymehrotra.com/REFORM-reading-group/assets/12_02_2026_Double_Descent_2.pdf) [Paper 1](https://arxiv.org/abs/1912.02292) [Paper 2](https://arxiv.org/abs/1908.05355) |
| 2026-02-19 | Overfitting and Generalization 2: Benign Overfitting | |




